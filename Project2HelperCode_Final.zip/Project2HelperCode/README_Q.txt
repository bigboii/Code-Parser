README
The commandline arguments work as the following:
/../TestFiles1 *.h *.cpp

The first argument represents the specified folder
The second argument is a pattern that searches for header files
The 3rd argument is a pattern that search for cpp files.

If you would like to test this on different directories, I made a another test directory called TestFiles2.
Just replace the 1st command line argument with /../TestFiles2

The program should work with all other directories too.