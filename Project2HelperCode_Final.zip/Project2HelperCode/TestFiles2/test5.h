void fun5()
{
	if(1)
	{
		while()
		{
			
		}
	}
	else
	{
		
	}
	for()
	{
		
	}
}