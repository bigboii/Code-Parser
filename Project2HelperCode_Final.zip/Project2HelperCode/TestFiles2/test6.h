void fun6() 
{
	if(1)
	{
		if(1)
		{
			if(1)
			{
				if(1)
				{
		
				}
			}
		}
	}
}