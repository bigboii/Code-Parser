void fun4() 
{
	if()
	{
		
	}
}

void fun44() 
{
	if()
	{
		
	}
	else
	{
		
	}
}