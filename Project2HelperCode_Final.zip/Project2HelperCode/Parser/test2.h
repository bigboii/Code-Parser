void fun()
{
	if(1)
	{
		for()
		{
			
		}
	}
	while()
	{
		if()
		{
			
		}
	}
}