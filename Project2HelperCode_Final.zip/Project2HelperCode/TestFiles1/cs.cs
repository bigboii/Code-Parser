void fun1() 
{
	if()
	{
		
	}
}