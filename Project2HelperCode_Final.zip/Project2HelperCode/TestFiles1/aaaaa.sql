void fun3() 
{
	while()
	{
		
	}
}