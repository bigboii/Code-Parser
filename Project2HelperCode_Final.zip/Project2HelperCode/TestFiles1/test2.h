void fun2()
{
	if(1)
	{
		for()
		{
			
		}
	}
	while()
	{
		if()
		{
			
		}
	}
}

void fun22() 
{
	if()
	{
		
	}
	else
	{
		
	}
}