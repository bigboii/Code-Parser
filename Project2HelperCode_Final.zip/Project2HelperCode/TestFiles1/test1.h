void fun1() 
{
	if()
	{
		
	}
	if()
	{
		
	}
	if()
	{
		
	}

	if(1)
	{
		if(1)
		{
			if(1)
			{
				if(1)
				{
		
				}
			}
		}
	}
}